<?php
/**
 * 系统环境检测工具
 * 用于验证服务器环境是否符合要求
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统环境检测</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 {
            color: #1890ff;
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .check-item {
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 6px;
            border-left: 4px solid #ddd;
        }
        .check-item.success {
            background: #f6ffed;
            border-left-color: #52c41a;
        }
        .check-item.error {
            background: #fff1f0;
            border-left-color: #ff4d4f;
        }
        .check-item.warning {
            background: #fffbe6;
            border-left-color: #faad14;
        }
        .check-title {
            font-weight: bold;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        .icon {
            margin-right: 10px;
            font-size: 20px;
        }
        .check-detail {
            color: #666;
            font-size: 13px;
            margin-top: 5px;
            padding-left: 30px;
        }
        .summary {
            margin-top: 30px;
            padding: 20px;
            background: #f0f2f5;
            border-radius: 6px;
        }
        .summary h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 20px;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: #1890ff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-top: 20px;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #096dd9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #e8e8e8;
        }
        table th {
            background: #fafafa;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 系统环境检测</h1>
        <p class="subtitle">检测服务器环境是否符合硬件调试工具站的运行要求</p>

        <?php
        $checks = [];
        $errors = 0;
        $warnings = 0;
        $success = 0;

        // 检查PHP版本
        $php_version = phpversion();
        if (version_compare($php_version, '7.4.0', '>=')) {
            $checks[] = [
                'status' => 'success',
                'title' => 'PHP版本',
                'message' => "当前版本: {$php_version} (要求: 7.4+)",
                'detail' => 'PHP版本符合要求'
            ];
            $success++;
        } else {
            $checks[] = [
                'status' => 'error',
                'title' => 'PHP版本',
                'message' => "当前版本: {$php_version} (要求: 7.4+)",
                'detail' => '请升级PHP到7.4或更高版本'
            ];
            $errors++;
        }

        // 检查PDO扩展
        if (extension_loaded('pdo_mysql')) {
            $checks[] = [
                'status' => 'success',
                'title' => 'PDO MySQL扩展',
                'message' => 'PDO MySQL扩展已启用',
                'detail' => '可以正常连接MySQL数据库'
            ];
            $success++;
        } else {
            $checks[] = [
                'status' => 'error',
                'title' => 'PDO MySQL扩展',
                'message' => 'PDO MySQL扩展未启用',
                'detail' => '请在php.ini中启用extension=pdo_mysql'
            ];
            $errors++;
        }

        // 检查MySQL连接
        try {
            require_once __DIR__ . '/config/database.php';
            $db = getDB();
            $checks[] = [
                'status' => 'success',
                'title' => 'MySQL数据库连接',
                'message' => '数据库连接成功',
                'detail' => '可以正常连接到MySQL服务器'
            ];
            $success++;
        } catch (Exception $e) {
            $checks[] = [
                'status' => 'error',
                'title' => 'MySQL数据库连接',
                'message' => '数据库连接失败',
                'detail' => '错误: ' . $e->getMessage() . '<br>请检查config/database.php配置'
            ];
            $errors++;
        }

        // 检查数据库表
        if (isset($db)) {
            $required_tables = ['settings', 'page_stats', 'serial_logs', 'admin_users'];
            
            // 兼容MySQL和SQLite获取表名
            if (DB_TYPE === 'sqlite') {
                $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table'");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } else {
                $stmt = $db->query("SHOW TABLES");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
            
            $missing_tables = array_diff($required_tables, $tables);
            
            if (empty($missing_tables)) {
                $checks[] = [
                    'status' => 'success',
                    'title' => '数据库表',
                    'message' => '所有必需的表都已创建',
                    'detail' => '找到 ' . count($tables) . ' 个表'
                ];
                $success++;
            } else {
                $checks[] = [
                    'status' => 'error',
                    'title' => '数据库表',
                    'message' => '缺少必需的表: ' . implode(', ', $missing_tables),
                    'detail' => '请执行 database/install.sql 导入数据库'
                ];
                $errors++;
            }
        }

        // 检查文件权限
        $writable_dirs = ['assets/images'];
        foreach ($writable_dirs as $dir) {
            if (is_writable(__DIR__ . '/' . $dir)) {
                $checks[] = [
                    'status' => 'success',
                    'title' => '目录权限: ' . $dir,
                    'message' => '目录可写',
                    'detail' => ''
                ];
                $success++;
            } else {
                $checks[] = [
                    'status' => 'warning',
                    'title' => '目录权限: ' . $dir,
                    'message' => '目录不可写',
                    'detail' => '如需上传功能,请设置 chmod 777 ' . $dir
                ];
                $warnings++;
            }
        }

        // 检查关键文件
        $required_files = [
            'index.php',
            'config/database.php',
            'includes/functions.php',
            'includes/auth.php',
            'database/install.sql',
            'assets/css/style.css',
            'assets/css/admin.css'
        ];
        
        $missing_files = [];
        foreach ($required_files as $file) {
            if (!file_exists(__DIR__ . '/' . $file)) {
                $missing_files[] = $file;
            }
        }
        
        if (empty($missing_files)) {
            $checks[] = [
                'status' => 'success',
                'title' => '核心文件',
                'message' => '所有核心文件都存在',
                'detail' => '共检查 ' . count($required_files) . ' 个文件'
            ];
            $success++;
        } else {
            $checks[] = [
                'status' => 'error',
                'title' => '核心文件',
                'message' => '缺少文件: ' . implode(', ', $missing_files),
                'detail' => '请确保所有文件都已上传'
            ];
            $errors++;
        }

        // 检查mod_rewrite
        if (function_exists('apache_get_modules')) {
            $modules = apache_get_modules();
            if (in_array('mod_rewrite', $modules)) {
                $checks[] = [
                    'status' => 'success',
                    'title' => 'Apache mod_rewrite',
                    'message' => 'mod_rewrite模块已启用',
                    'detail' => 'URL重写功能正常'
                ];
                $success++;
            } else {
                $checks[] = [
                    'status' => 'error',
                    'title' => 'Apache mod_rewrite',
                    'message' => 'mod_rewrite模块未启用',
                    'detail' => '请在Apache配置中启用mod_rewrite'
                ];
                $errors++;
            }
        } else {
            $checks[] = [
                'status' => 'warning',
                'title' => 'Web服务器',
                'message' => '无法检测Web服务器类型',
                'detail' => '如果不是Apache,请确保配置了URL重写规则'
            ];
            $warnings++;
        }

        // 显示检查结果
        foreach ($checks as $check) {
            echo '<div class="check-item ' . $check['status'] . '">';
            echo '<div class="check-title">';
            if ($check['status'] === 'success') {
                echo '<span class="icon">✅</span>';
            } elseif ($check['status'] === 'error') {
                echo '<span class="icon">❌</span>';
            } else {
                echo '<span class="icon">⚠️</span>';
            }
            echo '<strong>' . $check['title'] . '</strong></div>';
            echo '<div>' . $check['message'] . '</div>';
            if (!empty($check['detail'])) {
                echo '<div class="check-detail">' . $check['detail'] . '</div>';
            }
            echo '</div>';
        }
        ?>

        <div class="summary">
            <h2>📊 检测结果汇总</h2>
            <table>
                <tr>
                    <th>检查项</th>
                    <th>数量</th>
                </tr>
                <tr style="color: #52c41a;">
                    <td>✅ 通过</td>
                    <td><strong><?php echo $success; ?></strong></td>
                </tr>
                <tr style="color: #faad14;">
                    <td>⚠️ 警告</td>
                    <td><strong><?php echo $warnings; ?></strong></td>
                </tr>
                <tr style="color: #ff4d4f;">
                    <td>❌ 错误</td>
                    <td><strong><?php echo $errors; ?></strong></td>
                </tr>
                <tr>
                    <td><strong>总计</strong></td>
                    <td><strong><?php echo $success + $warnings + $errors; ?></strong></td>
                </tr>
            </table>

            <?php if ($errors === 0): ?>
                <div style="margin-top: 20px; padding: 15px; background: #f6ffed; border-radius: 6px; color: #52c41a;">
                    <strong>🎉 恭喜!系统环境检测通过,可以正常使用!</strong>
                </div>
                <a href="/" class="btn">访问网站首页</a>
                <a href="/admin/login.php" class="btn" style="background: #52c41a; margin-left: 10px;">进入后台管理</a>
            <?php else: ?>
                <div style="margin-top: 20px; padding: 15px; background: #fff1f0; border-radius: 6px; color: #ff4d4f;">
                    <strong>⚠️ 发现 <?php echo $errors; ?> 个错误,请先解决这些问题后再使用系统。</strong>
                </div>
            <?php endif; ?>
        </div>

        <div style="margin-top: 30px; padding: 15px; background: #f0f2f5; border-radius: 6px; font-size: 13px; color: #666;">
            <strong>💡 提示:</strong> 完成此检测后,可以删除 check.php 文件以提高安全性。
        </div>
    </div>
</body>
</html>
