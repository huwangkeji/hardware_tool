<?php
/**
 * Session 诊断工具
 */

echo "<h2>🔍 Session 诊断报告</h2>";
echo "<hr>";

// 1. 检查 Session 状态
echo "<h3>1. Session 状态</h3>";
echo "<p>当前状态: ";
switch (session_status()) {
    case PHP_SESSION_DISABLED:
        echo "<strong style='color:red'>禁用</strong>";
        break;
    case PHP_SESSION_NONE:
        echo "<strong style='color:orange'>未启动</strong>";
        break;
    case PHP_SESSION_ACTIVE:
        echo "<strong style='color:green'>已启动 ✓</strong>";
        break;
}
echo "</p>";

// 2. 尝试启动 Session
echo "<h3>2. 启动 Session</h3>";
if (session_status() === PHP_SESSION_NONE) {
    echo "<p>正在启动 Session...</p>";
    $result = @session_start();
    if ($result) {
        echo "<p style='color:green'>✓ Session 启动成功</p>";
        echo "<p>Session ID: " . session_id() . "</p>";
    } else {
        echo "<p style='color:red'>✗ Session 启动失败</p>";
        echo "<p>错误信息: " . error_get_last()['message'] . "</p>";
    }
} else {
    echo "<p>Session 已经处于活动状态</p>";
    echo "<p>Session ID: " . session_id() . "</p>";
}

// 3. 检查 Session 配置
echo "<h3>3. Session 配置</h3>";
echo "<table border='1' cellpadding='5' cellspacing='0'>";
echo "<tr><th>配置项</th><th>值</th></tr>";
echo "<tr><td>session.save_path</td><td>" . ini_get('session.save_path') . "</td></tr>";
echo "<tr><td>session.name</td><td>" . ini_get('session.name') . "</td></tr>";
echo "<tr><td>session.use_cookies</td><td>" . ini_get('session.use_cookies') . "</td></tr>";
echo "<tr><td>session.cookie_secure</td><td>" . ini_get('session.cookie_secure') . "</td></tr>";
echo "<tr><td>session.cookie_httponly</td><td>" . ini_get('session.cookie_httponly') . "</td></tr>";
echo "<tr><td>session.gc_maxlifetime</td><td>" . ini_get('session.gc_maxlifetime') . "</td></tr>";
echo "</table>";

// 4. 测试写入和读取 Session
echo "<h3>4. Session 读写测试</h3>";
if (isset($_GET['test']) && $_GET['test'] == '1') {
    if (isset($_SESSION['test_data']) && $_SESSION['test_data'] == 'hello') {
        echo "<p style='color:green'>✓ Session 读写正常！写入和读取成功！</p>";
        echo "<p>读取到的数据: " . $_SESSION['test_data'] . "</p>";
    } else {
        echo "<p style='color:red'>✗ Session 读取失败！写入成功但读取不到数据</p>";
    }
    unset($_SESSION['test_data']);
} else {
    $_SESSION['test_data'] = 'hello';
    echo "<p>已写入测试数据到 Session...</p>";
    echo "<p><a href='?test=1'>点击这里测试读取</a></p>";
}

// 5. 检查 Session 文件目录权限
echo "<h3>5. Session 存储目录检查</h3>";
$sessionPath = ini_get('session.save_path');
if (empty($sessionPath)) {
    $sessionPath = sys_get_temp_dir();
}

echo "<p>存储路径: " . $sessionPath . "</p>";
if (is_dir($sessionPath)) {
    echo "<p style='color:green'>✓ 目录存在</p>";
    if (is_writable($sessionPath)) {
        echo "<p style='color:green'>✓ 目录可写</p>";
    } else {
        echo "<p style='color:red'>✗ 目录不可写！这是 Session 无法保存的原因！</p>";
    }
} else {
    echo "<p style='color:red'>✗ 目录不存在！</p>";
}

// 6. 测试 admin_logged_in 状态
echo "<h3>6. 管理员登录状态</h3>";
if (isset($_SESSION['admin_logged_in'])) {
    echo "<p>admin_logged_in = ";
    var_dump($_SESSION['admin_logged_in']);
    echo "</p>";
} else {
    echo "<p style='color:orange'>admin_logged_in 未设置（正常，未登录状态）</p>";
}

echo "<hr>";
echo "<h3>🔧 建议操作</h3>";
echo "<ol>";
echo "<li>如果 Session 读写测试失败，请检查 session.save_path 的目录权限</li>";
echo "<li>如果显示"目录不可写"，需要修改目录权限或在 config/app.php 中更改 save_path</li>";
echo "<li><strong>清除浏览器 Cookie：</strong>访问 <code>chrome://settings/siteData</code>，搜索 <code>127.0.0.1</code> 并删除</li>";
echo "<li>或者直接删除此文件：d:\\wwwroot\\127.0.0.1\\check_session.php</li>";
echo "</ol>";

echo "<hr>";
echo "<p style='color:red;'><strong>⚠️ 诊断完成后请立即删除此文件！</strong></p>";
