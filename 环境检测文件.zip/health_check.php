<?php
/**
 * 系统健康检查脚本
 * 全面检查所有组件是否正常
 */

// 引入配置文件以启动Session
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统健康检查</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Microsoft YaHei', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .header p {
            opacity: 0.9;
            font-size: 14px;
        }
        .content {
            padding: 30px;
        }
        .section {
            margin-bottom: 30px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f0f0f0;
        }
        .section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .section h2 {
            color: #333;
            font-size: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .section h2::before {
            content: '';
            width: 4px;
            height: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin-right: 10px;
            border-radius: 2px;
        }
        .check-item {
            display: flex;
            align-items: flex-start;
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .check-item:hover {
            background: #f5f5f5;
        }
        .check-icon {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            flex-shrink: 0;
            font-weight: bold;
            font-size: 14px;
        }
        .check-icon.success {
            background: #52c41a;
            color: white;
        }
        .check-icon.error {
            background: #ff4d4f;
            color: white;
        }
        .check-icon.warning {
            background: #faad14;
            color: white;
        }
        .check-content {
            flex: 1;
        }
        .check-title {
            font-weight: 500;
            color: #333;
            margin-bottom: 4px;
        }
        .check-desc {
            font-size: 13px;
            color: #666;
        }
        .summary {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border: 2px solid #667eea;
            border-radius: 12px;
            padding: 20px;
            margin-top: 30px;
        }
        .summary h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-box {
            background: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .stat-value.success { color: #52c41a; }
        .stat-value.error { color: #ff4d4f; }
        .stat-value.warning { color: #faad14; }
        .stat-label {
            font-size: 13px;
            color: #666;
        }
        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        .btn-secondary:hover {
            background: #667eea;
            color: white;
        }
        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            color: #ff4d4f;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 系统健康检查</h1>
            <p>硬件调试工具站 - 全面诊断报告</p>
        </div>

        <div class="content">
            <?php
            $totalChecks = 0;
            $passedChecks = 0;
            $failedChecks = 0;
            $warningChecks = 0;

            function checkItem($title, $condition, $successMsg = '', $errorMsg = '') {
                global $totalChecks, $passedChecks, $failedChecks, $warningChecks;
                $totalChecks++;
                
                if ($condition === true) {
                    $passedChecks++;
                    echo '<div class="check-item">';
                    echo '<div class="check-icon success">✓</div>';
                    echo '<div class="check-content">';
                    echo '<div class="check-title">' . htmlspecialchars($title) . '</div>';
                    echo '<div class="check-desc">' . htmlspecialchars($successMsg) . '</div>';
                    echo '</div></div>';
                } elseif ($condition === 'warning') {
                    $warningChecks++;
                    echo '<div class="check-item">';
                    echo '<div class="check-icon warning">!</div>';
                    echo '<div class="check-content">';
                    echo '<div class="check-title">' . htmlspecialchars($title) . '</div>';
                    echo '<div class="check-desc">' . htmlspecialchars($errorMsg) . '</div>';
                    echo '</div></div>';
                } else {
                    $failedChecks++;
                    echo '<div class="check-item">';
                    echo '<div class="check-icon error">✗</div>';
                    echo '<div class="check-content">';
                    echo '<div class="check-title">' . htmlspecialchars($title) . '</div>';
                    echo '<div class="check-desc">' . htmlspecialchars($errorMsg) . '</div>';
                    echo '</div></div>';
                }
            }
            ?>

            <!-- PHP环境检查 -->
            <div class="section">
                <h2>PHP环境检查</h2>
                <?php
                checkItem(
                    'PHP版本',
                    version_compare(PHP_VERSION, '7.4.0', '>='),
                    '当前版本: ' . PHP_VERSION,
                    '需要PHP 7.4或更高版本，当前版本: ' . PHP_VERSION
                );

                checkItem(
                    'PDO扩展',
                    extension_loaded('pdo'),
                    'PDO扩展已启用',
                    'PDO扩展未启用，请在php.ini中启用'
                );

                checkItem(
                    'PDO MySQL驱动',
                    extension_loaded('pdo_mysql'),
                    'MySQL驱动已加载',
                    'MySQL驱动未加载，请安装php-mysql扩展'
                );

                checkItem(
                    'PDO SQLite驱动',
                    extension_loaded('pdo_sqlite'),
                    'SQLite驱动已加载',
                    'SQLite驱动未加载（如果使用MySQL可忽略）'
                );

                checkItem(
                    'JSON扩展',
                    extension_loaded('json'),
                    'JSON扩展已启用',
                    'JSON扩展未启用'
                );

                checkItem(
                    'Session支持',
                    session_status() === PHP_SESSION_ACTIVE,
                    'Session功能正常 (ID: ' . session_id() . ')',
                    'Session无法启动，请检查PHP配置和目录权限'
                );
                ?>
            </div>

            <!-- 文件权限检查 -->
            <div class="section">
                <h2>文件和目录权限</h2>
                <?php
                $rootDir = __DIR__;
                checkItem(
                    '项目根目录可读',
                    is_readable($rootDir),
                    '根目录: ' . $rootDir,
                    '根目录不可读，请检查权限'
                );

                checkItem(
                    'config目录可读',
                    is_readable(__DIR__ . '/config'),
                    '配置文件目录正常',
                    'config目录不可读'
                );

                checkItem(
                    'assets目录可读',
                    is_readable(__DIR__ . '/assets'),
                    '静态资源目录正常',
                    'assets目录不可读'
                );

                checkItem(
                    'database目录可写',
                    is_writable(__DIR__ . '/database'),
                    '数据库目录可写',
                    'database目录不可写，可能导致SQLite无法创建'
                );
                ?>
            </div>

            <!-- 静态资源检查 -->
            <div class="section">
                <h2>静态资源文件</h2>
                <?php
                $cssFile = __DIR__ . '/assets/css/style.css';
                checkItem(
                    '前端CSS文件',
                    file_exists($cssFile),
                    '文件大小: ' . round(filesize($cssFile) / 1024, 2) . ' KB',
                    '文件不存在: /assets/css/style.css'
                );

                $adminCssFile = __DIR__ . '/assets/css/admin.css';
                checkItem(
                    '后台CSS文件',
                    file_exists($adminCssFile),
                    '文件大小: ' . round(filesize($adminCssFile) / 1024, 2) . ' KB',
                    '文件不存在: /assets/css/admin.css'
                );

                $jsFile = __DIR__ . '/assets/js/main.js';
                checkItem(
                    '前端JS文件',
                    file_exists($jsFile),
                    '文件大小: ' . round(filesize($jsFile) / 1024, 2) . ' KB',
                    '文件不存在: /assets/js/main.js'
                );

                $chartFile = __DIR__ . '/assets/js/chart.min.js';
                checkItem(
                    'Chart.js库',
                    file_exists($chartFile),
                    '文件大小: ' . round(filesize($chartFile) / 1024, 2) . ' KB',
                    '文件不存在: /assets/js/chart.min.js'
                );

                $logoFile = __DIR__ . '/assets/images/logo.svg';
                checkItem(
                    'Logo图片',
                    file_exists($logoFile),
                    'SVG格式Logo存在',
                    'Logo文件不存在'
                );

                $faviconFile = __DIR__ . '/assets/images/favicon.svg';
                checkItem(
                    'Favicon图标',
                    file_exists($faviconFile),
                    'SVG格式Favicon存在',
                    'Favicon文件不存在'
                );
                ?>
            </div>

            <!-- 核心文件检查 -->
            <div class="section">
                <h2>核心PHP文件</h2>
                <?php
                checkItem(
                    'index.php',
                    file_exists(__DIR__ . '/index.php'),
                    '前端入口文件存在',
                    '前端入口文件缺失'
                );

                checkItem(
                    'admin/login.php',
                    file_exists(__DIR__ . '/admin/login.php'),
                    '登录页面存在',
                    '登录页面缺失'
                );

                checkItem(
                    'config/database.php',
                    file_exists(__DIR__ . '/config/database.php'),
                    '数据库配置文件存在',
                    '数据库配置文件缺失'
                );

                checkItem(
                    'includes/functions.php',
                    file_exists(__DIR__ . '/includes/functions.php'),
                    '函数库文件存在',
                    '函数库文件缺失'
                );
                ?>
            </div>

            <!-- 数据库连接检查 -->
            <div class="section">
                <h2>数据库连接</h2>
                <?php
                try {
                    require_once __DIR__ . '/config/database.php';
                    $db = getDB();
                    
                    checkItem(
                        '数据库连接',
                        true,
                        '成功连接到 ' . (DB_TYPE === 'mysql' ? 'MySQL' : 'SQLite') . ' 数据库',
                        ''
                    );

                    // 测试查询
                    $stmt = $db->query("SELECT 1 as test");
                    $result = $stmt->fetch();
                    
                    checkItem(
                        '数据库查询',
                        $result && $result['test'] == 1,
                        '数据库查询功能正常',
                        '数据库查询失败'
                    );

                    // 检查表是否存在
                    if (DB_TYPE === 'mysql') {
                        $stmt = $db->query("SHOW TABLES LIKE 'settings'");
                        $tableExists = $stmt->rowCount() > 0;
                    } else {
                        $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='settings'");
                        $tableExists = $stmt->rowCount() > 0;
                    }

                    checkItem(
                        '数据表存在',
                        $tableExists,
                        'settings表存在',
                        'settings表不存在，请运行数据库安装脚本'
                    );

                } catch (Exception $e) {
                    checkItem(
                        '数据库连接',
                        false,
                        '',
                        '连接失败: ' . $e->getMessage()
                    );
                }
                ?>
            </div>

            <!-- 服务器信息 -->
            <div class="section">
                <h2>服务器信息</h2>
                <?php
                checkItem(
                    '服务器软件',
                    'warning',
                    '',
                    $_SERVER['SERVER_SOFTWARE'] ?? '未知'
                );

                checkItem(
                    '文档根目录',
                    'warning',
                    '',
                    $_SERVER['DOCUMENT_ROOT'] ?? '未知'
                );

                checkItem(
                    '请求URI',
                    'warning',
                    '',
                    $_SERVER['REQUEST_URI'] ?? '未知'
                );

                $isNginx = stripos($_SERVER['SERVER_SOFTWARE'] ?? '', 'nginx') !== false;
                checkItem(
                    'Web服务器类型',
                    $isNginx ? 'warning' : true,
                    $isNginx ? '检测到Nginx（建议配置NGINX_SETUP.md中的规则）' : 'Apache或其他',
                    '检测到Nginx，请确保已配置静态资源规则'
                );
                ?>
            </div>

            <!-- 总结和建议 -->
            <div class="summary">
                <h3>📊 检查总结</h3>
                <div class="summary-stats">
                    <div class="stat-box">
                        <div class="stat-value success"><?php echo $passedChecks; ?></div>
                        <div class="stat-label">通过检查</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value error"><?php echo $failedChecks; ?></div>
                        <div class="stat-label">失败检查</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value warning"><?php echo $warningChecks; ?></div>
                        <div class="stat-label">警告项</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value" style="color: #667eea;"><?php echo $totalChecks; ?></div>
                        <div class="stat-label">总检查数</div>
                    </div>
                </div>

                <?php if ($failedChecks === 0): ?>
                    <p style="color: #52c41a; font-weight: 500; margin-bottom: 15px;">
                        ✅ 恭喜！所有关键检查都已通过，系统运行正常。
                    </p>
                <?php else: ?>
                    <p style="color: #ff4d4f; font-weight: 500; margin-bottom: 15px;">
                        ⚠️ 发现 <?php echo $failedChecks; ?> 个失败项，请及时修复以确保系统正常运行。
                    </p>
                <?php endif; ?>

                <?php if ($isNginx): ?>
                    <p style="color: #faad14; margin-bottom: 15px;">
                        💡 检测到您使用Nginx服务器，建议按照 <code>NGINX_SETUP.md</code> 配置静态资源规则以获得最佳性能。
                    </p>
                <?php endif; ?>

                <div class="actions">
                    <a href="/" class="btn btn-primary">访问首页</a>
                    <a href="/admin/login.php" class="btn btn-secondary">后台登录</a>
                    <a href="/test_static.php" class="btn btn-secondary">静态资源测试</a>
                    <button onclick="location.reload()" class="btn btn-secondary">重新检查</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
